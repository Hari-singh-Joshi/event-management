from django.shortcuts import render,redirect
from django.views import View
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import VendorRegistrationForm,LoginForm, ProductForm
from .models import Product,Vendor
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import login as auth_login
from django.contrib.auth import authenticate
from django.contrib.auth.decorators import login_required
from .forms import UserRegistrationForm, UserLoginForm
from django.contrib.auth.models import User
# Home page view
def home(request):
    return render(request, "app/home.html")
def vendor(request):
    return render(request, "app/vendor.html")

def UserView(request):
    return render(request, "app/user.html")


# About page view
def about(request):
    return render(request, "app/about.html")

# Contact page view
def contact(request):
    return render(request, "app/contact.html")

class VendorResistrationaView(View):
    def get(self, request):
        form = VendorRegistrationForm()
        return render(request, "app/vendorregistration.html", locals())

    def post(self, request):
        form = VendorRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Congratulations! Successfully Registered.")
        else:
            messages.warning(request, "Invalid Input Data")
        return render(request, "app/vendorregistration.html", locals())

# Login view
def LoginView(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                login(request, user)
                messages.success(request, "You have successfully logged in.")
                return redirect('vendor')  # Redirect to the vendor after login
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid input.")
    
    else:
        form = LoginForm()
    
    return render(request, "app/login.html",locals())


@login_required
def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            product.vendor = request.user  # Set the logged-in user as the vendor
            product.save()
            return redirect('product_list')  # Redirect to a product list view or similar
    else:
        form = ProductForm()
    
    return render(request, 'app/add_product.html', {'form': form})
@login_required
def product_list(request):
    products = Product.objects.all()
    return render(request, 'app/product_list.html',locals())
@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        product.delete()
        return HttpResponseRedirect(reverse('product_list'))
    return render(request, 'app/confirm_delete.html', locals())

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('user_home')  # Redirect to a user home page or another page
    else:
        form = UserRegistrationForm()
    return render(request, 'app/register.html',locals())

def user_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            return redirect('user_home')  # Redirect to a user home page or another page
    else:
        form = UserLoginForm()
    return render(request, 'app/ulogin.html',locals())

@login_required
def user_home(request):
    return render(request, 'app/user_home.html')

def vendor_list(request):
    # Fetch users from the admin
    users = User.objects.all()
    return render(request, 'app/vendors.html', {'users': users})

def vendor_products(request, vendor_id):
    # Get the vendor (user) or return a 404 if not found
    vendor = get_object_or_404(User, id=vendor_id)
    # Filter products by the selected vendor
    products = Product.objects.filter(vendor=vendor)
    
    return render(request, 'app/vendor_products.html', {
        'vendor': vendor,
        'products': products
    })
# from django.shortcuts import redirect, render
# from django.http import JsonResponse
# from django.views import View
# from django.db.models import Q
# from .models import Cart, Product

# def add_to_cart(request, vendor_id):
#     user = request.user
#     product_id = request.GET.get('prod_id')
    
#     try:
#         product = Product.objects.get(id=product_id, vendor_id=vendor_id)
#     except Product.DoesNotExist:
#         return JsonResponse({'error': 'Product not found or does not belong to this vendor'}, status=404)
    
#     cart_item, created = Cart.objects.get_or_create(user=user, product=product)
#     if not created:
#         cart_item.quantity += 1
#         cart_item.save()
    
#     return redirect('add_to_cart', vendor_id=vendor.id)



# def show_cart(request):
#     user = request.user
#     cart = Cart.objects.filter(user=user)
#     amount = sum(item.total_cost for item in cart)  # Use total_cost property
#     totalamount = amount + 40  # Including shipping charges
#     return render(request, 'app/addtocart.html', {'cart': cart, 'amount': amount, 'totalamount': totalamount})

# class Checkout(View):
#     def get(self, request):
#         user = request.user
#         add = Product.objects.filter(user=user)
#         cart_items = Cart.objects.filter(user=user)
#         famount = sum(item.total_cost for item in cart_items)  # Use total_cost property
#         totalamount = famount + 40  # Including shipping charges
#         return render(request, 'app/checkout.html', {'cart_items': cart_items, 'famount': famount, 'totalamount': totalamount})

# def plus_cart(request):
#     if request.method == 'GET':
#         prod_id = request.GET.get('prod_id')
#         try:
#             cart_item = Cart.objects.get(Q(product_id=prod_id) & Q(user=request.user))
#         except Cart.DoesNotExist:
#             return JsonResponse({'error': 'Cart item not found'}, status=404)

#         cart_item.quantity += 1
#         cart_item.save()

#         # Recalculating amount and totalamount after updating quantity
#         user = request.user
#         cart = Cart.objects.filter(user=user)
#         amount = sum(item.total_cost for item in cart)  # Use total_cost property
#         totalamount = amount + 40  # Including shipping charges

#         data = {
#             'quantity': cart_item.quantity,
#             'amount': amount,
#             'totalamount': totalamount,
#         }
#         return JsonResponse(data)

# def minus_cart(request):
#     if request.method == 'GET':
#         prod_id = request.GET.get('prod_id')
#         try:
#             cart_item = Cart.objects.get(Q(product_id=prod_id) & Q(user=request.user))
#         except Cart.DoesNotExist:
#             return JsonResponse({'error': 'Cart item not found'}, status=404)

#         if cart_item.quantity > 1:
#             cart_item.quantity -= 1
#             cart_item.save()
#         else:
#             cart_item.delete()  # If quantity becomes 0, remove the item from the cart

#         # Recalculating amount and totalamount after updating quantity
#         user = request.user
#         cart = Cart.objects.filter(user=user)
#         amount = sum(item.total_cost for item in cart)  # Use total_cost property
#         totalamount = amount + 40  # Including shipping charges

#         data = {
#             'quantity': cart_item.quantity if cart_item.quantity > 0 else 0,
#             'amount': amount,
#             'totalamount': totalamount,
#         }
#         return JsonResponse(data)

# def remove_cart(request):
#     if request.method == 'GET':
#         prod_id = request.GET.get('prod_id')
#         carts = Cart.objects.filter(Q(product_id=prod_id) & Q(user=request.user))

#         if carts.exists():
#             carts.delete()
#             user = request.user
#             cart_items = Cart.objects.filter(user=user)
#             amount = sum(item.total_cost for item in cart_items)  # Use total_cost property
#             totalamount = amount + 40  # Including shipping charges
#             data = {
#                 'quantity': 0,  # No items left, so quantity is 0
#                 'amount': amount,
#                 'totalamount': totalamount
#             }
#         else:
#             data = {
#                 'quantity': 0,
#                 'amount': 0,
#                 'totalamount': 40  # Shipping charges only
#             }

#         return JsonResponse(data)
