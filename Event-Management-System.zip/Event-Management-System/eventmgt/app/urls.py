from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .forms import LoginForm
urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path('users/', views.UserView, name='users'),
    path("contact/", views.contact, name="contact"),
    path("vendor/", views.vendor, name="vendor"),
    path('vendor/add_product/', views.add_product, name='add_product'),
    path('vendor/products/', views.product_list, name='product_list'),
    path('vendor/delete_product/<int:product_id>/', views.delete_product, name='delete_product'),
    path('register/', views.register, name='register'),
    path('ulogin/', views.user_login, name='ulogin'),
    path('user_home/', views.user_home, name='user_home'),
    path('vendors/', views.vendor_list, name='vendor_list'),
    path('vendor/<str:vendor_id>/', views.vendor_products, name='vendor_products'),
    # path('add_to_cart/<str:vendor_id>/', views.add_to_cart, name='add_to_cart'),
    # path("cart/", views.show_cart, name="showcart"),
    #  path("checkout/", views.Checkout.as_view(), name="checkout"),
    # path("pluscart/", views.plus_cart),
    # path("minuscart/", views.minus_cart),
    # path("removecart/", views.remove_cart),


    #Authentication and Password management
    path("vregistration/", views.VendorResistrationaView.as_view(), name="vregistration"),
    path('accounts/login/', auth_views.LoginView.as_view(
        template_name='app/login.html',
        authentication_form=LoginForm
    ), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    
    # path('password-reset/', auth_views.PasswordResetView.as_view(
    #     template_name='app/password-reset.html',
    #     form_class=MyPasswordResetForm
    # ), name='password-reset'),
    
    # path('passwordchange/', auth_views.PasswordChangeView.as_view(
    #     template_name='app/changepassword.html',
    #     form_class=MyPasswordChangeForm,
    #     success_url='/passwordchangedone'
    # ), name='passwordchange'),
    
    # path('passwordchangedone/', auth_views.PasswordChangeDoneView.as_view(
    #     template_name='app/passwordchangedone.html'
    # ), name='passwordchangedone'),

    # path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(
    # template_name='app/password_reset_done.html'
    # ), name='password_reset_done'),

    
    # path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(
    #     template_name='app/password_reset_confirm.html',
    #     form_class=MySetPasswordForm
    # ), name='password_reset_confirm'),

    # path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(
    #     template_name='app/password-reset-complete.html'
    # ), name='password_reset_complete'),
    
]  + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
